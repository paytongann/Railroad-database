
DELIMITER //
CREATE PROCEDURE discount(
in id int, out discount numeric(4,2))
BEGIN	
	declare emptySeats int;
    declare percent float;
    select distinct emptySeatsOnTrain(id) into emptySeats from train;
	if emptySeats > 10 then
		set percent = .05;
	elseif emptySeats > 20 then
		set percent = .10;
	elseif emptySeats > 30 then
		set percent = .15;
	elseif emptySeats > 40 then
		set percent = .2;
	end if;
    set discount = percent;
END //
DELIMITER ;

call discount(1,@disc);
select @disc as discount;