#1 Number of stations
Select count(stationId) as "Number of stations" from station;
#2 Number of tickets sold
Select count(ticketId) as "Number of ticket sold" from passenger;
#3 Number of routes less than 10 miles
Select count(distanceInMiles) as "Number of routes less than 10 miles apart" from route
	where distanceInMiles < 10;
#4 Sum of money for all the tickets sold
select sum(price) as "Sum of all tickets sold" from ticket join passenger
	where ticket.ticketId = passenger.ticketId;
#5 Select all people who are on train number one schedule one
select firstName, lastName from passenger
	join ticket on passenger.ticketId = ticket.ticketId
	where ticket.scheduleId = 1
    order by firstName, lastName desc;
#6 Select name of the station with the largest distance
select max(distanceInMiles) as "Max distance between stations"from route;
#7 Select the number of trains leaving at 8am on 2019-05-01
select count(schedule.trainId) "Trains leaving at date/time" from schedule 
	where departureDate = "2019-05-01"
    and departureTime = "8:00";
#8 Select all the station addresses with the word drive in it
select stationId, address from station
	where address like "%drive%";
#9 Select route numbers with more than 2 ticket sold
select route.routeId as "Route Id", count(ticket.ticketId) as "Ticket sold for route" from route
	join schedule on route.routeId = schedule.routeId
    join ticket on schedule.scheduleId = ticket.scheduleId
    join passenger on ticket.ticketId = passenger.ticketId
    group by route.routeId
    having count(ticket.scheduleId) > 2;
#10 Selects passenger name and their seat number
Select passenger.firstName, passenger.lastName, ticket.seatNumber from passenger
	join ticket on ticket.ticketId =  passenger.ticketId
    order by seatNumber desc;
    