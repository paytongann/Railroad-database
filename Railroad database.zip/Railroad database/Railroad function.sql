# Select how many empty seats there are on train number one schedule one
#Function
    
delimiter //
create function emptySeatsOnTrain(MytrainId int)
returns numeric (10,2) deterministic
begin
	declare maxSeats int;
    declare id int;
    declare ticketsSold int;
    select numberOfSeats into maxSeats from train
		where train.trainId = MytrainId;
	select schedule.scheduleId , count(ticket.ticketId) into id, ticketsSold from ticket
		join schedule on ticket.scheduleId = schedule.scheduleId
		join passenger on ticket.ticketId = passenger.ticketId
		join route on schedule.routeId = route.routeId
		group by ticket.scheduleId
		having schedule.scheduleId = MytrainIds;
    return maxSeats-ticketsSold;
End //
delimiter ;

select schedule.scheduleId, emptySeatsOnTrain(train.trainId) from train
	join schedule on train.trainId=schedule.trainId
    where emptySeatsOnTrain(train.trainId);