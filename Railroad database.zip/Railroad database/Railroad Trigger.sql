#Trigger Inserting a station creates a new route for the station to connect too
delimiter //
create trigger computeStation
	after insert on station
	for each row
begin
	declare station int;
    declare routeMax int;
    select stationId into station from station
		where stationId = new.stationId;
	select max(routeId) +1 into routeMax from route;
	insert into route values(
		routeMax, station, 1, 23
    );
End //
delimiter ;

insert into station values(
	51, "411 Washington", "Stephenville", "76402"
);