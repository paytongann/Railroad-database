#Problem 1
Select first_name, last_name from employees
join dept_emp on employees.emp_no = dept_emp.emp_no
where dept_emp.dept_no = "d001"
order by last_name, first_name; 

#Problem 2
Select departments.dept_name, sum(dept_emp.dept_no) as "Number of Employees" from employees
join dept_emp on employees.emp_no = dept_emp.emp_no
join departments on dept_emp.dept_no = departments.dept_no
group by departments.dept_name
order by sum(dept_emp.dept_no);

#Problem 3
Select employees.first_name, employees.last_name, departments.dept_name from employees
join dept_manager on employees.emp_no = dept_manager.emp_no
join departments on dept_manager.dept_no = departments.dept_no
order by departments.dept_name;

#Problem 4
Select employees.emp_no, employees.first_name, employees.last_name from employees
join dept_emp on employees.emp_no = dept_emp.emp_no
where dept_emp.to_date < current_date()
order by employees.emp_no asc;

#Problem 5
Select employees.emp_no, employees.first_name, employees.last_name from employees
join dept_manager on employees.emp_no = dept_manager.emp_no
order by employees.emp_no asc;