insert into station values(
	"1", "7997 NW. Leeton Ridge Rd.", "West New York", "07093"
);
insert into station values(
	"2", "321 Trout Dr. ", "Fort Washington", "20744"
);
insert into station values(
	"3", "8389 Alton St.", "Crawfordsville", "47933"
);
insert into station values(
	"4", "8247 Sherman Ave.", "Perth Amboy", "08861"
);
insert into station values(
	"5", "977 Glen Ridge Ave.", "Iowa City", "52240"
);
insert into station values(
	"6", "312 W. Fairground Ave. ", "Battle Creek", "49015"
);
insert into station values(
	"7", "80 Oklahoma Drive", "Corpus", "78418"
);
insert into station values(
	"8", "2 High Point Street", "Wilmette", "60091"
);
insert into station values(
	"9", "8153 Shore Street", "Norristown", "19401"
);
insert into station values(
	"10", "8751 Lookout St.", "Westfield", "01085"
);
insert into station values(
	"11", "1 W. Hillcrest Street", "Far Rockaway", "11691"
);
insert into station values(
	"12", "839 Manhattan Dr.", "Hixson", "37343"
);
insert into station values(
	"13", "7453 Snake Hill Lane", "Auburndale", "33823"
);
insert into station values(
	"14", "73 North Park Lane", "Berwyn", "60402"
);
insert into station values(
	"15", "10 San Juan Ave.", "Shelton", "06484"
);
insert into station values(
	"16", "72 High Ave.", "Opa Locka", "33054"
);
insert into station values(
	"17", "445 Iroquois Street", "Palos Verdes Peninsula", "90274"
);
insert into station values(
	"18", "55 Newport St.", "Windermere", "34786"
);
insert into station values(
	"19", "71 Academy Lane", "Lake Mary", "32746"
);
insert into station values(
	"20", "8174 South Penn Dr. ", "Wantagh", "11793"
);
insert into station values(
	"21", "376 Hall Ave.", "Cincinnati", "Cincinnati"
);
insert into station values(
	"22", "491 Amerige Avenue", "Savannah", "31404"
);
insert into station values(
	"23", "9404 Water St.", "Collierville", "38017"
);
insert into station values(
	"24", "66 Gates Drive", "Ogden", "84404"
);
insert into station values(
	"25", "570 Longfellow Lane", "Dekalb", "60115"
);
insert into station values(
	"26", "77 Lake Forest St.", "Decatur", "30030"
);
insert into station values(
	"27", "631 Main Ave", "Royal Oak", "48067"
);
insert into station values(
	"28", "7078 Hall Street", "Mundelein", "60060"
);
insert into station values(
	"29", "453 Glendale Dr. ", "Springfield Gardens,", "11413"
);
insert into station values(
	"30", "55 Manchester Court ", "Franklin Square", "11010"
);
insert into station values(
	"31", "8 Augusta Rd.", "Santa Cruz", "95060"
);
insert into station values(
	"32", "5 South Marsh Ave.", "Rockville", "20850"
);
insert into station values(
	"33", "51 1st Drive", "Randolph", "02368"
);
insert into station values(
	"34", "149 W. Gregory Ave.", "Zanesville", "43701"
);
insert into station values(
	"35", "379 N. Hanover Ave.", "Enterprise", "36330"
);
insert into station values(
	"36", "8307 Purple Finch Ave.", "Hillsborough", "08844"
);
insert into station values(
	"37", "9104 N. Grandrose St. ", "Peoria", "61604"
);
insert into station values(
	"38", "8759 Sugar St.", "Ravenna", "Ravenna"
);
insert into station values(
	"39", "7709 Holly Dr.", "Carmel", "10512"
);
insert into station values(
	"40", "17 Shore Street", "Grandville", "49418"
);
insert into station values(
	"41", "9121 Mechanic Drive", "Huntington", "11743"
);
insert into station values(
	"42", "748 Lancaster St.", "Marion", "28752"
);
insert into station values(
	"43", "79 West Armstrong Road", "Cocoa", "11010"
);
insert into station values(
	"44", "410 Prospect Court", "Onalaska", "54650"
);
insert into station values(
	"45", "4 Leeton Ridge Avenue", "Evans", "30809"
);
insert into station values(
	"46", "7887 Bayport Ave.", "Muscatine", "52761"
);
insert into station values(
	"47", "9138 Oakland St.", "Royal Oak", "48067"
);
insert into station values(
	"48", "305 W. Thomas Ave.", "Harvey", "60426"
);
insert into station values(
	"49", "116 San Juan Dr.", "Marlborough", "01752"
);
insert into station values(
	"50", "9400 Corona Drive", "Eastpointe", "48021"
);
insert into route values( 1, 1, 2, 4.9);
insert into route values( 2, 2, 3, 6.3);
insert into route values( 3, 3, 4, 6.3);
insert into route values( 4, 4, 5, 4.7);
insert into route values( 5, 5, 6, 12.6);
insert into route values( 6, 6, 7, 32);
insert into route values( 7, 7, 8, 3.5);
insert into route values( 8, 8, 9, 12);
insert into route values( 9, 9, 10, 10.3);
insert into route values( 10, 10, 11, 9.8);
insert into route values( 11, 11, 12, 6.9);
insert into route values( 12, 12, 13, 11);
insert into route values( 13, 13, 14, 32);
insert into route values( 14, 14, 15, 9.9);
insert into route values( 15, 15, 16, 16.4);
insert into route values( 16, 16, 17, 11.7);
insert into route values( 17, 17, 18, 28.9);
insert into route values( 18, 18, 19, 12.7);
insert into route values( 19, 19, 20, 19.4);
insert into route values( 20, 20, 21, 21.3);
insert into route values( 21, 21, 22, 35.2);
insert into route values( 22, 22, 23, 31);
insert into route values( 23, 23, 24, 19.4);
insert into route values( 24, 24, 1, 27.2);
insert into route values( 25, 25, 26, 18);
insert into route values( 26, 26, 27, 45.2);
insert into route values( 27, 27, 28, 23.8);
insert into route values( 28, 28, 29, 46.9);
insert into route values( 29, 29, 30, 24.8);
insert into route values( 30, 30, 31, 32);
insert into route values( 31, 31, 32, 34.4);
insert into route values( 32, 32, 33, 21.7);
insert into route values( 33, 33, 34, 17);
insert into route values( 34, 34, 35, 31);
insert into route values( 35, 35, 36, 12.7);
insert into route values( 36, 36, 37, 37);
insert into route values( 37, 37, 38, 13.3);
insert into route values( 38, 38, 39, 18);
insert into route values( 39, 39, 40, 29.4);
insert into route values( 40, 40, 41, 19.2);
insert into route values( 41, 41, 42, 31.4);
insert into route values( 42, 42, 43, 15.1);
insert into route values( 43, 43, 44, 22.5);
insert into route values( 44, 44, 45, 42.9);
insert into route values( 45, 45, 46, 35.9);
insert into route values( 46, 46, 47, 28.2);
insert into route values( 47, 47, 48, 10.2);
insert into route values( 48, 48, 49, 26);
insert into route values( 49, 49, 50, 14.3);
insert into route values( 50, 50, 25, 19.1);

insert into train values( 1 ,55);
insert into train values( 2 ,55);
insert into train values( 3 ,55);
insert into train values( 4 ,55);
insert into train values( 5 ,55);
insert into train values( 6 ,55);
insert into train values( 7 ,55);
insert into train values( 8 ,55);
insert into train values( 9 ,55);
insert into train values( 10 ,55);
insert into train values( 11 ,55);
insert into train values( 12 ,55);
insert into train values( 13 ,55);
insert into train values( 14 ,55);
insert into train values( 15 ,55);
insert into train values( 16 ,55);
insert into train values( 17 ,55);
insert into train values( 18 ,55);
insert into train values( 19 ,55);
insert into train values( 20 ,55);
insert into train values( 21 ,55);
insert into train values( 22 ,55);
insert into train values( 23 ,55);
insert into train values( 24 ,55);
insert into train values( 25 ,55);
insert into train values( 26 ,55);
insert into train values( 27 ,55);
insert into train values( 28 ,55);
insert into train values( 29 ,55);
insert into train values( 30 ,55);
insert into train values( 31 ,55);
insert into train values( 32 ,55);
insert into train values( 33 ,55);
insert into train values( 34 ,55);
insert into train values( 35 ,55);
insert into train values( 36 ,55);
insert into train values( 37 ,55);
insert into train values( 38 ,55);
insert into train values( 39 ,55);
insert into train values( 40 ,55);
insert into train values( 41 ,55);
insert into train values( 42 ,55);
insert into train values( 43 ,55);
insert into train values( 44 ,55);
insert into train values( 45 ,55);
insert into train values( 46 ,55);
insert into train values( 47 ,55);
insert into train values( 48 ,55);
insert into train values( 49 ,55);
insert into train values( 50 ,55);

insert into schedule values(  1 , "2019-05-01", "8:00",  1 ,  1  );
insert into schedule values(  2 , "2019-05-01", "8:00",  2 ,  2  );
insert into schedule values(  3 , "2019-05-01", "8:00",  3 ,  3  );
insert into schedule values(  4 , "2019-05-01", "8:00",  4 ,  4  );
insert into schedule values(  5 , "2019-05-01", "8:00",  5 ,  5  );
insert into schedule values(  6 , "2019-05-01", "8:00",  6 ,  6  );
insert into schedule values(  7 , "2019-05-01", "8:00",  7 ,  7  );
insert into schedule values(  8 , "2019-05-01", "8:00",  8 ,  8  );
insert into schedule values(  9 , "2019-05-01", "8:00",  9 ,  9  );
insert into schedule values(  10 , "2019-05-01", "8:00",  10 ,  10  );
insert into schedule values(  11 , "2019-05-01", "8:00",  11 ,  11  );
insert into schedule values(  12 , "2019-05-01", "8:00",  12 ,  12  );
insert into schedule values(  13 , "2019-05-01", "8:00",  13 ,  13  );
insert into schedule values(  14 , "2019-05-01", "8:00",  14 ,  14  );
insert into schedule values(  15 , "2019-05-01", "8:00",  15 ,  15  );
insert into schedule values(  16 , "2019-05-01", "8:00",  16 ,  16  );
insert into schedule values(  17 , "2019-05-01", "8:00",  17 ,  17  );
insert into schedule values(  18 , "2019-05-01", "8:00",  18 ,  18  );
insert into schedule values(  19 , "2019-05-01", "8:00",  19 ,  19  );
insert into schedule values(  20 , "2019-05-01", "8:00",  20 ,  20  );
insert into schedule values(  21 , "2019-05-01", "8:00",  21 ,  21  );
insert into schedule values(  22 , "2019-05-01", "8:00",  22 ,  22  );
insert into schedule values(  23 , "2019-05-01", "8:00",  23 ,  23  );
insert into schedule values(  24 , "2019-05-01", "8:00",  24 ,  24  );
insert into schedule values(  25 , "2019-05-01", "8:00",  25 ,  25  );
insert into schedule values(  26 , "2019-05-01", "8:00",  26 ,  26  );
insert into schedule values(  27 , "2019-05-01", "8:00",  27 ,  27  );
insert into schedule values(  28 , "2019-05-01", "8:00",  28 ,  28  );
insert into schedule values(  29 , "2019-05-01", "8:00",  29 ,  29  );
insert into schedule values(  30 , "2019-05-01", "8:00",  30 ,  30  );
insert into schedule values(  31 , "2019-05-01", "8:00",  31 ,  31  );
insert into schedule values(  32 , "2019-05-01", "8:00",  32 ,  32  );
insert into schedule values(  33 , "2019-05-01", "8:00",  33 ,  33  );
insert into schedule values(  34 , "2019-05-01", "8:00",  34 ,  34  );
insert into schedule values(  35 , "2019-05-01", "8:00",  35 ,  35  );
insert into schedule values(  36 , "2019-05-01", "8:00",  36 ,  36  );
insert into schedule values(  37 , "2019-05-01", "8:00",  37 ,  37  );
insert into schedule values(  38 , "2019-05-01", "8:00",  38 ,  38  );
insert into schedule values(  39 , "2019-05-01", "8:00",  39 ,  39  );
insert into schedule values(  40 , "2019-05-01", "8:00",  40 ,  40  );
insert into schedule values(  41 , "2019-05-01", "8:00",  41 ,  41  );
insert into schedule values(  42 , "2019-05-01", "8:00",  42 ,  42  );
insert into schedule values(  43 , "2019-05-01", "8:00",  43 ,  43  );
insert into schedule values(  44 , "2019-05-01", "8:00",  44 ,  44  );
insert into schedule values(  45 , "2019-05-01", "8:00",  45 ,  45  );
insert into schedule values(  46 , "2019-05-01", "8:00",  46 ,  46  );
insert into schedule values(  47 , "2019-05-01", "8:00",  47 ,  47  );
insert into schedule values(  48 , "2019-05-01", "8:00",  48 ,  48  );
insert into schedule values(  49 , "2019-05-01", "8:00",  49 ,  49  );
insert into schedule values(  50 , "2019-05-01", "8:00",  50 ,  50  );

insert into ticket values( 1 , 1 , 9.99, 1 );
insert into ticket values( 2 , 1 , 9.99, 2 );
insert into ticket values( 3 , 1 , 9.99, 3 );
insert into ticket values( 4 , 1 , 9.99, 4 );
insert into ticket values( 5 , 1 , 9.99, 5 );
insert into ticket values( 6 , 1 , 9.99, 6 );
insert into ticket values( 7 , 1 , 9.99, 7 );
insert into ticket values( 8 , 1 , 9.99, 8 );
insert into ticket values( 9 , 1 , 9.99, 9 );
insert into ticket values( 10 , 1 , 9.99, 10 );
insert into ticket values( 11 , 1 , 9.99, 11 );
insert into ticket values( 12 , 1 , 9.99, 12 );
insert into ticket values( 13 , 1 , 9.99, 13 );
insert into ticket values( 14 , 1 , 9.99, 14 );
insert into ticket values( 15 , 1 , 9.99, 15 );
insert into ticket values( 16 , 1 , 9.99, 16 );
insert into ticket values( 17 , 1 , 9.99, 17 );
insert into ticket values( 18 , 1 , 9.99, 18 );
insert into ticket values( 19 , 1 , 9.99, 19 );
insert into ticket values( 20 , 1 , 9.99, 20 );
insert into ticket values( 21 , 1 , 9.99, 21 );
insert into ticket values( 22 , 1 , 9.99, 22 );
insert into ticket values( 23 , 1 , 9.99, 23 );
insert into ticket values( 24 , 1 , 9.99, 24 );
insert into ticket values( 25 , 1 , 9.99, 25 );
insert into ticket values( 26 , 1 , 9.99, 26 );
insert into ticket values( 27 , 1 , 9.99, 27 );
insert into ticket values( 28 , 1 , 9.99, 28 );
insert into ticket values( 29 , 1 , 9.99, 29 );
insert into ticket values( 30 , 1 , 9.99, 30 );
insert into ticket values( 31 , 1 , 9.99, 31 );
insert into ticket values( 32 , 1 , 9.99, 32 );
insert into ticket values( 33 , 1 , 9.99, 33 );
insert into ticket values( 34 , 1 , 9.99, 34 );
insert into ticket values( 35 , 1 , 9.99, 35 );
insert into ticket values( 36 , 1 , 9.99, 36 );
insert into ticket values( 37 , 1 , 9.99, 37 );
insert into ticket values( 38 , 1 , 9.99, 38 );
insert into ticket values( 39 , 1 , 9.99, 39 );
insert into ticket values( 40 , 1 , 9.99, 40 );
insert into ticket values( 41 , 1 , 9.99, 41 );
insert into ticket values( 42 , 1 , 9.99, 42 );
insert into ticket values( 43 , 1 , 9.99, 43 );
insert into ticket values( 44 , 1 , 9.99, 44 );
insert into ticket values( 45 , 1 , 9.99, 45 );
insert into ticket values( 46 , 1 , 9.99, 46 );
insert into ticket values( 47 , 1 , 9.99, 47 );
insert into ticket values( 48 , 1 , 9.99, 48 );
insert into ticket values( 49 , 1 , 9.99, 49 );
insert into ticket values( 50 , 1 , 9.99, 50 );
insert into ticket values( 51 , 2 , 12.99, 1 );
insert into ticket values( 52 , 2 , 12.99, 2 );
insert into ticket values( 53 , 2 , 12.99, 3 );
insert into ticket values( 54 , 2 , 12.99, 4 );
insert into ticket values( 55 , 2 , 12.99, 5 );
insert into ticket values( 56 , 2 , 12.99, 6 );
insert into ticket values( 57 , 2 , 12.99, 7 );
insert into ticket values( 58 , 2 , 12.99, 8 );
insert into ticket values( 59 , 2 , 12.99, 9 );
insert into ticket values( 60 , 2 , 12.99, 10 );
insert into ticket values( 61 , 2 , 12.99, 11 );
insert into ticket values( 62 , 2 , 12.99, 12 );
insert into ticket values( 63 , 2 , 12.99, 13 );
insert into ticket values( 64 , 2 , 12.99, 14 );
insert into ticket values( 65 , 2 , 12.99, 15 );
insert into ticket values( 66 , 2 , 12.99, 16 );
insert into ticket values( 67 , 2 , 12.99, 17 );
insert into ticket values( 68 , 2 , 12.99, 18 );
insert into ticket values( 69 , 2 , 12.99, 19 );
insert into ticket values( 70 , 2 , 12.99, 20 );
insert into ticket values( 71 , 2 , 12.99, 21 );
insert into ticket values( 72 , 2 , 12.99, 22 );
insert into ticket values( 73 , 2 , 12.99, 23 );
insert into ticket values( 74 , 2 , 12.99, 24 );
insert into ticket values( 75 , 2 , 12.99, 25 );
insert into ticket values( 76 , 2 , 12.99, 26 );
insert into ticket values( 77 , 2 , 12.99, 27 );
insert into ticket values( 78 , 2 , 12.99, 28 );
insert into ticket values( 79 , 2 , 12.99, 29 );
insert into ticket values( 80 , 2 , 12.99, 30 );
insert into ticket values( 81 , 2 , 12.99, 31 );
insert into ticket values( 82 , 2 , 12.99, 32 );
insert into ticket values( 83 , 2 , 12.99, 33 );
insert into ticket values( 84 , 2 , 12.99, 34 );
insert into ticket values( 85 , 2 , 12.99, 35 );
insert into ticket values( 86 , 2 , 12.99, 36 );
insert into ticket values( 87 , 2 , 12.99, 37 );
insert into ticket values( 88 , 2 , 12.99, 38 );
insert into ticket values( 89 , 2 , 12.99, 39 );
insert into ticket values( 90 , 2 , 12.99, 40 );
insert into ticket values( 91 , 2 , 12.99, 41 );
insert into ticket values( 92 , 2 , 12.99, 42 );
insert into ticket values( 93 , 2 , 12.99, 43 );
insert into ticket values( 94 , 2 , 12.99, 44 );
insert into ticket values( 95 , 2 , 12.99, 45 );
insert into ticket values( 96 , 2 , 12.99, 46 );
insert into ticket values( 97 , 2 , 12.99, 47 );
insert into ticket values( 98 , 2 , 12.99, 48 );
insert into ticket values( 99 , 2 , 12.99, 49 );
insert into ticket values( 100 , 2 , 12.99, 50 );
insert into ticket values( 101 , 3 , 7.99, 1 );
insert into ticket values( 102 , 3 , 7.99, 2 );
insert into ticket values( 103 , 3 , 7.99, 3 );
insert into ticket values( 104 , 3 , 7.99, 4 );
insert into ticket values( 105 , 3 , 7.99, 5 );
insert into ticket values( 106 , 3 , 7.99, 6 );
insert into ticket values( 107 , 3 , 7.99, 7 );
insert into ticket values( 108 , 3 , 7.99, 8 );
insert into ticket values( 109 , 3 , 7.99, 9 );
insert into ticket values( 110 , 3 , 7.99, 10 );
insert into ticket values( 111 , 3 , 7.99, 11 );
insert into ticket values( 112 , 3 , 7.99, 12 );
insert into ticket values( 113 , 3 , 7.99, 13 );
insert into ticket values( 114 , 3 , 7.99, 14 );
insert into ticket values( 115 , 3 , 7.99, 15 );
insert into ticket values( 116 , 3 , 7.99, 16 );
insert into ticket values( 117 , 3 , 7.99, 17 );
insert into ticket values( 118 , 3 , 7.99, 18 );
insert into ticket values( 119 , 3 , 7.99, 19 );
insert into ticket values( 120 , 3 , 7.99, 20 );
insert into ticket values( 121 , 3 , 7.99, 21 );
insert into ticket values( 122 , 3 , 7.99, 22 );
insert into ticket values( 123 , 3 , 7.99, 23 );
insert into ticket values( 124 , 3 , 7.99, 24 );
insert into ticket values( 125 , 3 , 7.99, 25 );
insert into ticket values( 126 , 3 , 7.99, 26 );
insert into ticket values( 127 , 3 , 7.99, 27 );
insert into ticket values( 128 , 3 , 7.99, 28 );
insert into ticket values( 129 , 3 , 7.99, 29 );
insert into ticket values( 130 , 3 , 7.99, 30 );
insert into ticket values( 131 , 3 , 7.99, 31 );
insert into ticket values( 132 , 3 , 7.99, 32 );
insert into ticket values( 133 , 3 , 7.99, 33 );
insert into ticket values( 134 , 3 , 7.99, 34 );
insert into ticket values( 135 , 3 , 7.99, 35 );
insert into ticket values( 136 , 4 , 11.99, 1 );
insert into ticket values( 137 , 4 , 11.99, 2 );
insert into ticket values( 138 , 4 , 11.99, 3 );
insert into ticket values( 139 , 4 , 11.99, 4 );
insert into ticket values( 140 , 4 , 11.99, 5 );
insert into ticket values( 141 , 4 , 11.99, 6 );
insert into ticket values( 142 , 4 , 11.99, 7 );
insert into ticket values( 143 , 4 , 11.99, 8 );
insert into ticket values( 144 , 4 , 11.99, 9 );
insert into ticket values( 145 , 4 , 11.99, 10 );
insert into ticket values( 146 , 4 , 11.99, 11 );
insert into ticket values( 147 , 4 , 11.99, 12 );
insert into ticket values( 148 , 4 , 11.99, 13 );
insert into ticket values( 149 , 4 , 11.99, 14 );
insert into ticket values( 150 , 4 , 11.99, 15 );
insert into ticket values( 151 , 4 , 11.99, 16 );
insert into ticket values( 152 , 4 , 11.99, 17 );
insert into ticket values( 153 , 4 , 11.99, 18 );
insert into ticket values( 154 , 4 , 11.99, 19 );
insert into ticket values( 155 , 4 , 11.99, 20 );
insert into ticket values( 156 , 4 , 11.99, 21 );
insert into ticket values( 157 , 4 , 11.99, 22 );
insert into ticket values( 158 , 4 , 11.99, 23 );
insert into ticket values( 159 , 4 , 11.99, 24 );
insert into ticket values( 160 , 4 , 11.99, 25 );
insert into ticket values( 161 , 4 , 11.99, 26 );
insert into ticket values( 162 , 4 , 11.99, 27 );
insert into ticket values( 163 , 4 , 11.99, 28 );
insert into ticket values( 164 , 4 , 11.99, 29 );
insert into ticket values( 165 , 4 , 11.99, 30 );
insert into ticket values( 166 , 4 , 11.99, 31 );
insert into ticket values( 167 , 4 , 11.99, 32 );
insert into ticket values( 168 , 4 , 11.99, 33 );
insert into ticket values( 169 , 4 , 11.99, 34 );
insert into ticket values( 170 , 4 , 11.99, 35 );
insert into ticket values( 171 , 4 , 11.99, 36 );
insert into ticket values( 172 , 4 , 11.99, 37 );
insert into ticket values( 173 , 4 , 11.99, 38 );
insert into ticket values( 174 , 4 , 11.99, 39 );
insert into ticket values( 175 , 4 , 11.99, 40 );
insert into ticket values( 176 , 4 , 11.99, 41 );
insert into ticket values( 177 , 4 , 11.99, 42 );
insert into ticket values( 178 , 4 , 11.99, 43 );
insert into ticket values( 179 , 4 , 11.99, 44 );
insert into ticket values( 180 , 4 , 11.99, 45 );
insert into ticket values( 181 , 4 , 11.99, 46 );
insert into ticket values( 182 , 4 , 11.99, 47 );
insert into ticket values( 183 , 4 , 11.99, 48 );
insert into ticket values( 184 , 4 , 11.99, 49 );
insert into ticket values( 185 , 4 , 11.99, 50 );
insert into ticket values( 190 ,  5 , 8.99, 1);
insert into ticket values( 191 ,  6 , 8.99, 1);
insert into ticket values( 192 ,  7 , 8.99, 1);
insert into ticket values( 193 ,  8 , 8.99, 1);
insert into ticket values( 194 ,  9 , 8.99, 1);
insert into ticket values( 195 ,  10 , 8.99, 1);
insert into ticket values( 196 ,  11 , 8.99, 1);
insert into ticket values( 197 ,  12 , 8.99, 1);
insert into ticket values( 198 ,  13 , 8.99, 1);
insert into ticket values( 199 ,  14 , 8.99, 1);
insert into ticket values( 200 ,  15 , 8.99, 1);
insert into ticket values( 201 ,  16 , 8.99, 1);
insert into ticket values( 202 ,  17 , 8.99, 1);
insert into ticket values( 203 ,  18 , 8.99, 1);
insert into ticket values( 204 ,  19 , 8.99, 1);
insert into ticket values( 205 ,  20 , 8.99, 1);
insert into ticket values( 206 ,  21 , 8.99, 1);
insert into ticket values( 207 ,  22 , 8.99, 1);
insert into ticket values( 208 ,  23 , 8.99, 1);
insert into ticket values( 209 ,  24 , 8.99, 1);
insert into ticket values( 210 ,  25 , 8.99, 1);
insert into ticket values( 211 ,  26 , 8.99, 1);
insert into ticket values( 212 ,  27 , 8.99, 1);
insert into ticket values( 213 ,  28 , 8.99, 1);
insert into ticket values( 214 ,  29 , 8.99, 1);
insert into ticket values( 215 ,  30 , 8.99, 1);
insert into ticket values( 216 ,  31 , 8.99, 1);
insert into ticket values( 217 ,  32 , 8.99, 1);
insert into ticket values( 218 ,  33 , 8.99, 1);
insert into ticket values( 219 ,  34 , 8.99, 1);
insert into ticket values( 220 ,  35 , 8.99, 1);
insert into ticket values( 221 ,  36 , 8.99, 1);
insert into ticket values( 222 ,  37 , 8.99, 1);
insert into ticket values( 223 ,  38 , 8.99, 1);
insert into ticket values( 224 ,  39 , 8.99, 1);
insert into ticket values( 225 ,  40 , 8.99, 1);
insert into ticket values( 226 ,  41 , 8.99, 1);
insert into ticket values( 227 ,  42 , 8.99, 1);
insert into ticket values( 228 ,  43 , 8.99, 1);
insert into ticket values( 229 ,  44 , 8.99, 1);
insert into ticket values( 230 ,  45 , 8.99, 1);
insert into ticket values( 231 ,  46 , 8.99, 1);
insert into ticket values( 232 ,  47 , 8.99, 1);
insert into ticket values( 233 ,  48 , 8.99, 1);
insert into ticket values( 234 ,  49 , 8.99, 1);
insert into ticket values( 235 ,  50 , 8.99, 1);

insert into passenger values("Payton", "Gann", "paytongann@yahoo.com",1);
insert into passenger values("Eli", "Gann", "eligann@yahoo.com",2);
insert into passenger values("Elon", "musk", "telsa@business.com",3);
insert into passenger values("Michael", "Bender", "m2k2bend@yahoo.com",4);
insert into passenger values("tortal", "Angelo", "tortle@gmail.com",5);
insert into passenger values("Tom", "Brady", "patriotsWin@football.com",6);
insert into passenger values("Sadie", "Gann", "sgggw3@tarleton.edu",67);
insert into passenger values("Rocky", "bowwa", "rwbow@yahoo.com",123);
insert into passenger values("Scow", "Reaver", "scower@aol.com",125);
insert into passenger values("Daisy", "Frant", "dserfratn@yahoo.com",232);
insert into passenger values("tod", "dalie", "todalies@yahoo.com",233);
insert into passenger values("Addy", "Rake", "rakeadds@gmail.com",234);
insert into passenger values("Moxie", "Mable", "moxymable@yahoo.com",235);
insert into passenger values("Susan", "Johnson", "sjohnson@yahoo.com",55);
insert into passenger values("Max", "Williams", "Charoger@yahoo.com",56);
insert into passenger values("Yuhi", "Barnes", "ybarns@gmail.com",57);
insert into passenger values("Rolla", "Pam", "Rpam@yahoo.com",58);