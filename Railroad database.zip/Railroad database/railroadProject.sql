create database railroad;

use railroad;

create table station(
	stationId int (40),
    address varchar(40),
    city varchar(40),
    zipCode varchar(40),
    primary key(stationId)
);

create table route(
	routeId int(40),
	departureStationId int(40),
    arrivalStationId int(40),
    distanceInMiles decimal(40,2),
    primary key(routeId),
	foreign key (departureStationId) references station(stationId),
    foreign key (arrivalStationId) references station(stationId)
);

create table train(
	trainId varchar(40),
	numberOfSeats int(40),
    primary key(trainId)
);

create table schedule(
	scheduleId int(40),
    departureDate date,
    departureTime time(0),
    trainId varchar(40),
    routeId int(40),
    primary key (scheduleId),
    foreign key (routeId) references route(routeId),
    foreign key (trainId) references train(trainId)
);

create table ticket(
	ticketId int(40),
    scheduleId int(40),
    price decimal(40,2),
	seatNumber int(40),
    primary key (ticketId),
    foreign key (scheduleId) references schedule(scheduleId)
);

create table passenger(
	firstName varchar(40),
	lastName varchar(40),
    email varchar(40),
    ticketId int(40),
    foreign key (ticketId) references ticket(ticketId)
);
